window.setTimeout(function () {
    window.open('additional.html');
}, 5000);